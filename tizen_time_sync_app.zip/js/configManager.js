const ConfigManager = {
  async loadStoredConfig() {
    try {
      const value = localStorage.getItem("device_config");
      return value ? JSON.parse(value) : null;
    } catch (e) {
      console.error("No se pudo cargar la configuración almacenada:", e);
      return null;
    }
  },

  async saveConfig(config) {
    try {
      localStorage.setItem("device_config", JSON.stringify(config));
    } catch (e) {
      console.error("No se pudo guardar la configuración:", e);
    }
  },

  async loadDefaultConfig() {
    return fetch("config/default-config.json")
      .then((res) => res.json())
      .catch((err) => {
        console.error("Error al cargar configuración por defecto:", err);
        return null;
      });
  }
};