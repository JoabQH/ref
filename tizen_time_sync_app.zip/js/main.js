window.onload = async () => {
  const storedConfig = await ConfigManager.loadStoredConfig();
  const config = storedConfig || await ConfigManager.loadDefaultConfig();
  await TimeSync.sync(config);

  setTimeout(() => {
    try {
      tizen.application.getCurrentApplication().exit();
    } catch (e) {
      console.error("No se pudo cerrar la app:", e);
    }
  }, 4000);
};