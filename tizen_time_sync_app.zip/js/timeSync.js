const TimeSync = {
  async detectTimeZoneByIP() {
    try {
      const res = await fetch("https://worldtimeapi.org/api/ip");
      const data = await res.json();
      return {
        timezone: data.timezone,
        datetime: data.datetime
      };
    } catch (err) {
      console.error("Fallo la detección por IP:", err);
      return null;
    }
  },

  async setSystemTime(datetimeString) {
    try {
      const date = new Date(datetimeString);
      tizen.time.setCurrentDateTime(date);
      return true;
    } catch (e) {
      console.error("Error al ajustar la hora:", e);
      return false;
    }
  },

  async sync(config) {
    const statusElem = document.getElementById("status");

    const timeData = await this.detectTimeZoneByIP();

    if (timeData) {
      await this.setSystemTime(timeData.datetime);
      config.timezone = timeData.timezone;
      ConfigManager.saveConfig(config);
      statusElem.textContent = `Hora ajustada: ${timeData.timezone}`;
    } else {
      const defaultConfig = await ConfigManager.loadDefaultConfig();
      if (defaultConfig) {
        statusElem.textContent = `Usando configuración local: ${defaultConfig.timezone}`;
        await this.setSystemTime(new Date().toISOString());
        ConfigManager.saveConfig(defaultConfig);
      } else {
        statusElem.textContent = "No se pudo sincronizar.";
      }
    }
  }
};